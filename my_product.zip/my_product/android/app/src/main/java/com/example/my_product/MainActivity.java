package com.example.my_product;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
