import 'package:flutter/material.dart';

import 'package:http/http.dart' as http;
import 'dart:convert';
class Auth with ChangeNotifier{

}